package com.gcrj.projectcontrol.bean

class UserBean {

    var id: Int? = null
    var username: String? = null
    var token: String? = null

}