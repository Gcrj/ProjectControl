package com.gcrj.projectcontrol.bean

class ProjectBean {

    var id: Int? = null
    var name: String? = null
    var create_user: UserBean? = null

}