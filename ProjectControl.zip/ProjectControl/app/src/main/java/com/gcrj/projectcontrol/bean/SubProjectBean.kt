package com.gcrj.projectcontrol.bean

class SubProjectBean {

    var id: Int? = null
    var project_id: Int? = null
    var name: String? = null
    var progress: Int? = null

}