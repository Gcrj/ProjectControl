package com.gcrj.projectcontrol.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Created by zhangxin on 2018/9/17.
 */
class JPushReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {

    }

}