package com.gcrj.projectcontrol.bean

/**
 * Created by zhangxin on 2018/9/20.
 */
class RefreshProgress private constructor() {

    companion object {
        val INSTANCE = RefreshProgress()
    }

}